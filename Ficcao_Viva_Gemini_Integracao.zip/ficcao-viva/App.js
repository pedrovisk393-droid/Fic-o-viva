import React, { useEffect, useMemo, useState } from "react";
import {
  Alert, KeyboardAvoidingView, Platform, SafeAreaView, ScrollView,
  StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@ficcao_viva_stories_v1";
const GOLD = "#D99A32";
const BG = "#101014";
const PANEL = "#1B1B22";
const MUTED = "#A7A4AE";

const genres = ["Fantasia", "Aventura", "Mistério", "Romance", "Ficção científica", "Drama"];

function makeLocalDraft(title, genre, idea) {
  const cleanTitle = title.trim() || "Uma história sem título";
  const seed = idea.trim() || "um acontecimento inesperado muda o rumo de tudo";
  return `${cleanTitle}\n\n${genre} • Rascunho inicial\n\n${seed.charAt(0).toUpperCase() + seed.slice(1)}.\n\nTudo começou em um dia aparentemente comum. O cenário guardava pequenos sinais de que algo estava prestes a mudar, mas ninguém sabia interpretá-los.\n\nAo perceber que não poderia continuar seguindo o caminho de sempre, a personagem principal decidiu investigar. Cada descoberta trouxe uma nova pergunta, e cada escolha aproximou a história de um destino inesperado.\n\nEste é o começo. Continue escrevendo, acrescente personagens e transforme este rascunho na sua própria história.`;
}

export default function App() {
  const [tab, setTab] = useState("home");
  const [stories, setStories] = useState([]);
  const [title, setTitle] = useState("");
  const [idea, setIdea] = useState("");
  const [genre, setGenre] = useState("Fantasia");
  const [rating, setRating] = useState("Livre");
  const [draft, setDraft] = useState("");
  const [activeStory, setActiveStory] = useState(null);
  const [search, setSearch] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setStories(JSON.parse(raw));
      } catch (e) {
        Alert.alert("Aviso", "Não foi possível carregar a biblioteca local.");
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(stories)).catch(() => {});
  }, [stories, loaded]);

  const filteredStories = useMemo(() => {
    const q = search.trim().toLowerCase();
    return stories.filter(s => !q || s.title.toLowerCase().includes(q) || s.genre.toLowerCase().includes(q));
  }, [stories, search]);

  async function createDraft() {
    if (!title.trim() && !idea.trim()) {
      Alert.alert("Falta uma ideia", "Digite um título ou conte um pouco sobre sua história.");
      return;
    }
    if (rating === "18+") {
      Alert.alert("Conteúdo restrito", "A criação 18+ permanece bloqueada nesta versão. O app foi preparado para uso seguro por adolescentes.");
      return;
    }

    const apiUrl = process.env.EXPO_PUBLIC_API_URL?.trim();
    if (!apiUrl) {
      setDraft(makeLocalDraft(title, genre, idea));
      setTab("editor");
      Alert.alert(
        "Modo de demonstração",
        "O servidor Gemini ainda não foi configurado. Criamos um rascunho local para você continuar. Quando o servidor estiver publicado e EXPO_PUBLIC_API_URL estiver definido, a criação por IA será ativada."
      );
      return;
    }

    try {
      const response = await fetch(`${apiUrl.replace(/\/$/, "")}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          idea: idea.trim(),
          genre,
          language: "pt-BR"
        })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || "Não foi possível gerar a história.");
      }
      if (!data?.text) throw new Error("O servidor não retornou um texto.");
      setDraft(data.text);
      setTab("editor");
    } catch (error) {
      Alert.alert(
        "Não foi possível conectar à IA",
        `${error.message || "Verifique sua conexão."}\n\nVocê pode continuar com um rascunho local.`,
        [
          { text: "Tentar novamente", style: "cancel" },
          { text: "Usar rascunho local", onPress: () => { setDraft(makeLocalDraft(title, genre, idea)); setTab("editor"); } }
        ]
      );
    }
  }

  function saveStory() {
    const storyTitle = title.trim() || "História sem título";
    if (!draft.trim()) {
      Alert.alert("Nada para salvar", "Crie um rascunho primeiro.");
      return;
    }
    const item = {
      id: String(Date.now()),
      title: storyTitle,
      genre,
      rating,
      content: draft,
      updatedAt: new Date().toISOString()
    };
    setStories(prev => [item, ...prev]);
    setActiveStory(item);
    setTab("library");
    Alert.alert("História salva", "Seu texto foi guardado nesta biblioteca, neste aparelho.");
  }

  function openStory(item) {
    setActiveStory(item);
    setTitle(item.title);
    setGenre(item.genre);
    setRating(item.rating);
    setDraft(item.content);
    setTab("editor");
  }

  function deleteStory(id) {
    Alert.alert("Excluir história?", "Esta ação não poderá ser desfeita.", [
      { text: "Cancelar", style: "cancel" },
      { text: "Excluir", style: "destructive", onPress: () => setStories(prev => prev.filter(s => s.id !== id)) }
    ]);
  }

  function NavButton({ id, label, icon }) {
    const selected = tab === id;
    return (
      <TouchableOpacity style={styles.navItem} onPress={() => setTab(id)}>
        <Text style={[styles.navIcon, selected && styles.goldText]}>{icon}</Text>
        <Text style={[styles.navLabel, selected && styles.goldText]}>{label}</Text>
      </TouchableOpacity>
    );
  }

  function Header() {
    return (
      <View style={styles.header}>
        <View style={styles.brandMark}><Text style={styles.brandFeather}>✦</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.brand}>FICÇÃO VIVA</Text>
          <Text style={styles.tagline}>Sua imaginação, infinitas histórias.</Text>
        </View>
        <View style={styles.localBadge}><Text style={styles.localBadgeText}>LOCAL</Text></View>
      </View>
    );
  }

  function Home() {
    return (
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>BEM-VINDO AO SEU UNIVERSO</Text>
        <Text style={styles.heroTitle}>Toda grande história começa com uma ideia.</Text>
        <Text style={styles.bodyText}>Crie mundos, invente personagens e guarde suas histórias em um só lugar.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => { setDraft(""); setTitle(""); setIdea(""); setTab("studio"); }}>
          <Text style={styles.primaryButtonText}>＋  Criar uma história</Text>
        </TouchableOpacity>
        <View style={styles.statsRow}>
          <View style={styles.statCard}><Text style={styles.statNumber}>{stories.length}</Text><Text style={styles.statLabel}>Histórias salvas</Text></View>
          <View style={styles.statCard}><Text style={styles.statNumber}>∞</Text><Text style={styles.statLabel}>Possibilidades</Text></View>
        </View>
        <Text style={styles.sectionTitle}>Seu espaço criativo</Text>
        <View style={styles.featureCard}><Text style={styles.featureIcon}>✍️</Text><View style={{flex:1}}><Text style={styles.featureTitle}>Estúdio de criação</Text><Text style={styles.featureText}>Organize sua ideia e comece um novo rascunho.</Text></View></View>
        <View style={styles.featureCard}><Text style={styles.featureIcon}>📚</Text><View style={{flex:1}}><Text style={styles.featureTitle}>Sua biblioteca</Text><Text style={styles.featureText}>Encontre os textos que você salvou neste aparelho.</Text></View></View>
        <View style={styles.note}><Text style={styles.noteTitle}>Sobre esta primeira versão</Text><Text style={styles.noteText}>A criação funciona localmente, sem exigir conta ou internet. A geração por IA, login Google e sincronização online precisam de um backend e credenciais próprios, que ainda não foram fornecidos.</Text></View>
      </ScrollView>
    );
  }

  function Studio() {
    return (
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>ESTÚDIO DE CRIAÇÃO</Text>
        <Text style={styles.pageTitle}>Dê vida à sua ideia</Text>
        <Text style={styles.fieldLabel}>Título da história</Text>
        <TextInput value={title} onChangeText={setTitle} placeholder="Ex.: O segredo da floresta" placeholderTextColor="#77737F" style={styles.input} />
        <Text style={styles.fieldLabel}>Gênero</Text>
        <View style={styles.chips}>{genres.map(g => <TouchableOpacity key={g} onPress={() => setGenre(g)} style={[styles.chip, genre === g && styles.chipActive]}><Text style={[styles.chipText, genre === g && styles.chipTextActive]}>{g}</Text></TouchableOpacity>)}</View>
        <Text style={styles.fieldLabel}>Sua ideia</Text>
        <TextInput value={idea} onChangeText={setIdea} placeholder="Conte o que acontece, quem são os personagens ou como começa..." placeholderTextColor="#77737F" style={[styles.input, styles.multiline]} multiline textAlignVertical="top" />
        <Text style={styles.fieldLabel}>Classificação</Text>
        <View style={styles.chips}>
          {["Livre", "18+"].map(r => <TouchableOpacity key={r} onPress={() => setRating(r)} style={[styles.chip, rating === r && styles.chipActive]}><Text style={[styles.chipText, rating === r && styles.chipTextActive]}>{r}</Text></TouchableOpacity>)}
        </View>
        {rating === "18+" && <Text style={styles.warning}>A classificação 18+ aparece apenas como marcador. Conteúdo adulto permanece bloqueado nesta versão inicial.</Text>}
        <TouchableOpacity style={styles.primaryButton} onPress={createDraft}><Text style={styles.primaryButtonText}>Criar rascunho</Text></TouchableOpacity>
      </ScrollView>
    );
  }

  function Editor() {
    return (
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{flex:1}}>
        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.eyebrow}>EDITOR DE HISTÓRIA</Text>
          <Text style={styles.pageTitle}>Seu texto</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="Título" placeholderTextColor="#77737F" style={styles.input} />
          <TextInput value={draft} onChangeText={setDraft} multiline textAlignVertical="top" placeholder="Escreva sua história aqui..." placeholderTextColor="#77737F" style={[styles.input, styles.editorInput]} />
          <TouchableOpacity style={styles.primaryButton} onPress={saveStory}><Text style={styles.primaryButtonText}>Salvar na biblioteca</Text></TouchableOpacity>
          <TouchableOpacity style={styles.secondaryButton} onPress={() => setTab("studio")}><Text style={styles.secondaryButtonText}>Voltar ao estúdio</Text></TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  function Library() {
    return (
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>SEUS TEXTOS</Text>
        <Text style={styles.pageTitle}>Biblioteca</Text>
        <TextInput value={search} onChangeText={setSearch} placeholder="Buscar por título ou gênero..." placeholderTextColor="#77737F" style={styles.input} />
        {filteredStories.length === 0 ? (
          <View style={styles.empty}><Text style={styles.emptyIcon}>📖</Text><Text style={styles.emptyTitle}>Sua biblioteca está esperando</Text><Text style={styles.bodyText}>As histórias que você salvar aparecerão aqui.</Text></View>
        ) : filteredStories.map(item => (
          <View key={item.id} style={styles.storyCard}>
            <TouchableOpacity style={{flex:1}} onPress={() => openStory(item)}>
              <Text style={styles.storyTitle}>{item.title}</Text>
              <Text style={styles.storyMeta}>{item.genre}  •  {item.rating}</Text>
              <Text numberOfLines={2} style={styles.storyPreview}>{item.content}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => deleteStory(item.id)} style={styles.deleteButton}><Text style={styles.deleteText}>Excluir</Text></TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <Header />
      <View style={{flex:1}}>
        {tab === "home" && <Home />}
        {tab === "studio" && <Studio />}
        {tab === "editor" && <Editor />}
        {tab === "library" && <Library />}
      </View>
      <View style={styles.bottomNav}>
        <NavButton id="home" label="Início" icon="⌂" />
        <NavButton id="studio" label="Estúdio" icon="✎" />
        <NavButton id="library" label="Biblioteca" icon="▤" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#2B2930" },
  brandMark: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#382814", alignItems: "center", justifyContent: "center", marginRight: 12, borderWidth: 1, borderColor: GOLD },
  brandFeather: { color: GOLD, fontSize: 23 },
  brand: { color: "#F6F0E7", fontSize: 15, fontWeight: "900", letterSpacing: 2 },
  tagline: { color: MUTED, fontSize: 10, marginTop: 3 },
  localBadge: { borderWidth: 1, borderColor: "#66502D", borderRadius: 20, paddingHorizontal: 8, paddingVertical: 4 },
  localBadgeText: { color: GOLD, fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  content: { padding: 20, paddingBottom: 32 },
  eyebrow: { color: GOLD, fontSize: 10, fontWeight: "800", letterSpacing: 2, marginBottom: 10 },
  heroTitle: { color: "#F6F0E7", fontSize: 32, lineHeight: 39, fontWeight: "800", marginBottom: 12 },
  pageTitle: { color: "#F6F0E7", fontSize: 27, fontWeight: "800", marginBottom: 20 },
  bodyText: { color: MUTED, fontSize: 14, lineHeight: 22 },
  primaryButton: { backgroundColor: GOLD, padding: 16, borderRadius: 14, alignItems: "center", marginTop: 20 },
  primaryButtonText: { color: "#17120A", fontSize: 14, fontWeight: "900" },
  secondaryButton: { borderWidth: 1, borderColor: "#4B4651", padding: 15, borderRadius: 14, alignItems: "center", marginTop: 10 },
  secondaryButtonText: { color: "#E8E2DA", fontWeight: "700" },
  statsRow: { flexDirection: "row", gap: 12, marginTop: 22, marginBottom: 26 },
  statCard: { flex: 1, backgroundColor: PANEL, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: "#302E36" },
  statNumber: { color: GOLD, fontSize: 26, fontWeight: "900" },
  statLabel: { color: MUTED, fontSize: 11, marginTop: 4 },
  sectionTitle: { color: "#F6F0E7", fontSize: 17, fontWeight: "800", marginBottom: 12 },
  featureCard: { flexDirection: "row", alignItems: "center", backgroundColor: PANEL, borderRadius: 15, padding: 15, marginBottom: 10, gap: 13, borderWidth: 1, borderColor: "#302E36" },
  featureIcon: { fontSize: 25 },
  featureTitle: { color: "#F6F0E7", fontSize: 14, fontWeight: "800" },
  featureText: { color: MUTED, fontSize: 12, marginTop: 4, lineHeight: 18 },
  note: { backgroundColor: "#211D17", borderColor: "#554124", borderWidth: 1, borderRadius: 14, padding: 14, marginTop: 14 },
  noteTitle: { color: GOLD, fontWeight: "800", marginBottom: 6 },
  noteText: { color: "#C5BBAE", fontSize: 11, lineHeight: 18 },
  fieldLabel: { color: "#E9E3DB", fontSize: 13, fontWeight: "700", marginTop: 16, marginBottom: 8 },
  input: { backgroundColor: PANEL, color: "#F6F0E7", borderRadius: 12, borderWidth: 1, borderColor: "#393640", padding: 14, fontSize: 14 },
  multiline: { minHeight: 125 },
  editorInput: { minHeight: 330, lineHeight: 23, marginTop: 12 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { borderWidth: 1, borderColor: "#47424D", paddingHorizontal: 12, paddingVertical: 9, borderRadius: 20 },
  chipActive: { backgroundColor: "#3A2B17", borderColor: GOLD },
  chipText: { color: MUTED, fontSize: 12 },
  chipTextActive: { color: "#F2C16E", fontWeight: "800" },
  warning: { color: "#E7B96D", fontSize: 11, lineHeight: 17, marginTop: 10 },
  empty: { alignItems: "center", paddingVertical: 55 },
  emptyIcon: { fontSize: 38, marginBottom: 12 },
  emptyTitle: { color: "#F6F0E7", fontSize: 16, fontWeight: "800", marginBottom: 8 },
  storyCard: { backgroundColor: PANEL, borderWidth: 1, borderColor: "#35313B", borderRadius: 14, padding: 14, marginTop: 12, flexDirection: "row", gap: 10, alignItems: "center" },
  storyTitle: { color: "#F6F0E7", fontSize: 15, fontWeight: "800" },
  storyMeta: { color: GOLD, fontSize: 10, marginTop: 5, fontWeight: "700" },
  storyPreview: { color: MUTED, fontSize: 11, lineHeight: 17, marginTop: 7 },
  deleteButton: { padding: 8 },
  deleteText: { color: "#D98C80", fontSize: 11, fontWeight: "700" },
  bottomNav: { flexDirection: "row", borderTopWidth: 1, borderTopColor: "#2B2930", paddingTop: 9, paddingBottom: Platform.OS === "ios" ? 4 : 9, backgroundColor: "#15151A" },
  navItem: { flex: 1, alignItems: "center", paddingVertical: 5 },
  navIcon: { color: MUTED, fontSize: 21, marginBottom: 2 },
  navLabel: { color: MUTED, fontSize: 10, fontWeight: "700" },
  goldText: { color: GOLD }
});
