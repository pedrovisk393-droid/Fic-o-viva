# Ficção Viva — primeira versão Android

Este é um projeto inicial funcional em Expo/React Native, reconstruído a partir da descrição fornecida. Ele não é o código de um projeto anterior.

## O que já funciona
- Interface Android com identidade visual escura e detalhes âmbar.
- Início, Estúdio, Editor e Biblioteca.
- Criação de rascunho local a partir do título e da ideia informada.
- Edição e salvamento de histórias no armazenamento do aparelho.
- Busca e exclusão de histórias salvas.
- Classificação Livre/18+ como marcador. A opção 18+ fica bloqueada nesta versão e não gera conteúdo adulto.

## Limitações importantes desta versão
- **Não há geração real por IA ainda.** O botão cria um rascunho local de exemplo, sem chamar GPT ou outro serviço.
- **Não há login Google/Clerk ainda.** O uso atual é local, sem conta.
- **Não há backend nem sincronização online.** As histórias ficam no aparelho em que foram criadas.
- Para conectar IA, autenticação e sincronização, será necessário criar/fornecer um backend HTTPS e configurar autenticação e credenciais com segurança. Nunca coloque chaves secretas dentro do aplicativo.

## Como testar
É necessário um computador com Node.js LTS e acesso à internet.

1. Extraia o ZIP.
2. Abra um terminal dentro da pasta `ficcao-viva`.
3. Execute:

   ```bash
   npm install
   npx expo start
   ```

4. Instale o Expo Go no Android e leia o QR code exibido no terminal.

## Como gerar um APK instalável na nuvem (EAS)
1. Crie uma conta em https://expo.dev/ e entre nela.
2. No terminal, dentro da pasta do projeto, execute:

   ```bash
   npx eas-cli login
   npx eas-cli build:configure
   npx eas-cli build --platform android --profile preview
   ```

3. Na primeira compilação, aceite as configurações solicitadas pelo EAS.
4. Ao terminar, o EAS mostrará um link para baixar o APK.

O perfil `preview` já está configurado para gerar APK, não AAB.

## Próximas etapas para a versão completa
1. Criar um backend HTTPS para geração de histórias e persistência por usuário.
2. Integrar a API de IA somente no backend, nunca expondo a chave no app.
3. Configurar Clerk e login Google com as credenciais do projeto.
4. Criar regras de classificação, moderação e proteção adequadas antes de disponibilizar conteúdo 18+.
5. Adicionar sincronização e cópia de segurança da biblioteca.

## Identificação
- Nome: Ficção Viva
- Package Android: `com.ficcaoviva.app`
- Scheme: `ficcaoviva`
