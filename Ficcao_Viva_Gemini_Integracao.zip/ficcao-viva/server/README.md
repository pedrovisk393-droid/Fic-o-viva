# Servidor do Ficção Viva (Gemini)

Este servidor mantém a chave da API fora do APK e oferece `POST /api/generate`.

## Requisitos
- Node.js 20 ou superior.
- Um projeto Gemini API configurado no Google AI Studio por um responsável.
- Uma chave Gemini mantida como variável secreta no ambiente do servidor.

## Rodar localmente
1. Copie `.env.example` para `.env`.
2. Preencha `GEMINI_API_KEY` com a chave no ambiente do servidor. Não compartilhe a chave no chat, no ZIP ou no aplicativo.
3. Confirme no AI Studio que `GEMINI_MODEL` está disponível no nível gratuito da conta. O modelo padrão deste exemplo é apenas uma configuração inicial e pode precisar ser ajustado.
4. Execute:

   ```bash
   npm install
   npm start
   ```

5. Verifique `http://localhost:3000/health`.

## Endpoint
`POST /api/generate`

JSON:
```json
{
  "title": "A cidade das estrelas",
  "idea": "Uma jovem encontra um mapa escondido.",
  "genre": "Fantasia",
  "language": "pt-BR"
}
```

A resposta contém `{ "text": "...", "model": "..." }`.

## Segurança e limites
- A chave existe somente no servidor.
- Há limite básico de 8 chamadas por minuto por IP; para produção, use rate limit compartilhado e autenticação por usuário.
- CORS `*` é uma configuração inicial para desenvolvimento, não uma política final de produção.
- Este exemplo não tem login, banco de dados, quotas individuais nem proteção anti-abuso completa. Não publique amplamente sem autenticação, quotas por usuário, moderação, monitoramento e revisão de privacidade.
- O nível gratuito do Gemini tem limites variáveis e os dados enviados podem ser usados para melhorar os produtos do Google. Não envie dados pessoais, segredos ou informações sensíveis dos usuários.
- A classificação 18+ não está habilitada para geração nesta versão. O serviço foi configurado para ficção apropriada a adolescentes.
