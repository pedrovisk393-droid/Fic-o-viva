import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { GoogleGenAI } from "@google/genai";

const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const apiKey = process.env.GEMINI_API_KEY;

app.use(helmet());
app.use(cors({
  origin: (origin, callback) => {
    // Mobile clients may not send an Origin header. For a production web client,
    // replace ALLOWED_ORIGINS=* with a comma-separated allowlist.
    const allowed = (process.env.ALLOWED_ORIGINS || "*").split(",").map(x => x.trim());
    if (!origin || allowed.includes("*") || allowed.includes(origin)) return callback(null, true);
    return callback(new Error("Origem não permitida."));
  }
}));
app.use(express.json({ limit: "24kb" }));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Muitas solicitações. Aguarde um minuto e tente novamente." }
}));

const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "ficcao-viva-server", aiConfigured: Boolean(ai) });
});

app.post("/api/generate", async (req, res) => {
  if (!ai) {
    return res.status(503).json({ error: "A IA ainda não foi configurada no servidor." });
  }

  const title = typeof req.body?.title === "string" ? req.body.title.trim().slice(0, 120) : "";
  const idea = typeof req.body?.idea === "string" ? req.body.idea.trim().slice(0, 5000) : "";
  const genre = typeof req.body?.genre === "string" ? req.body.genre.trim().slice(0, 60) : "Fantasia";
  if (!title && !idea) {
    return res.status(400).json({ error: "Informe um título ou uma ideia para a história." });
  }

  // This first version deliberately serves general-audience creative writing only.
  // It does not generate sexual content or content intended to facilitate harm.
  const systemInstruction = [
    "Você é o assistente literário do aplicativo Ficção Viva.",
    "Responda em português brasileiro.",
    "Ajude a criar ficção original, apropriada para um público amplo e adolescente.",
    "Não produza conteúdo sexual explícito, exploração sexual, violência gráfica ou instruções para causar dano real.",
    "Quando houver tema sensível, trate-o de modo não gráfico e seguro.",
    "Crie um começo envolvente, personagens coerentes e uma direção clara para a narrativa.",
    "Não afirme que salvou o texto; o aplicativo fará isso separadamente."
  ].join(" ");

  const prompt = [
    `Gênero: ${genre}`,
    `Título: ${title || "Crie um título adequado"}`,
    `Ideia do usuário: ${idea || "Desenvolva uma premissa original a partir do título."}`,
    "",
    "Escreva um rascunho inicial em português brasileiro, com título, apresentação dos personagens e uma cena de abertura. Use parágrafos claros e deixe um gancho para continuação. Evite terminar a história inteira."
  ].join("\n");

  try {
    const result = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
        maxOutputTokens: 1400,
        temperature: 0.85
      }
    });
    const text = result.text?.trim();
    if (!text) return res.status(502).json({ error: "A IA não retornou texto. Tente novamente." });
    return res.json({ text, model });
  } catch (error) {
    // Do not expose provider details, credentials, or raw error messages to app users.
    console.error("Gemini request failed:", error?.message || "unknown error");
    return res.status(502).json({ error: "O serviço de IA está indisponível ou atingiu seu limite gratuito. Tente novamente mais tarde." });
  }
});

app.listen(port, () => {
  console.log(`Ficção Viva server listening on port ${port}`);
});
